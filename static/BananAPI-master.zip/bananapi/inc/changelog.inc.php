<?php
//Get changelog from database
$changelog = [];
$sql = "SELECT type,user,comment FROM update_log ORDER BY id DESC LIMIT 0,30";
$result = $sqlcon->query($sql);
if($result->num_rows > 0)
	while($row = $result->fetch_assoc())
		$changelog[count($changelog)] = $row;

//Replace values and remove some keys in the given array
//Normaly used 'rawTxtFormat(clientFormat($changelog))'
function clientFormat($in){
	for($i = 0; $i < count($in); $i++){
		$type = $in[$i]['type'];
		switch($type){
			case 'add':
				$type = '+';
				break;
			case 'fix':
				$type = '*';
				break;
			case 'comment':
				unset($in[$i]['type']);
				unset($in[$i]['user']);
				break;
		}
		if($type != 'comment')
			$in[$i]['type'] = $type;
	}
	return $in;
}

//Formats json into osu client format
function rawTxtFormat($json){
	$out = null;
	for($i = 0; $i < count($json); $i++){
		$k = array_keys($json[$i]);
		for($ii = 0; $ii < count($k); $ii++)
			$out .= $json[$i][$k[$ii]].(($ii == count($k)-1) ? null : "\t");
		$out .= "\n";
	}
	return $out;
}
?>