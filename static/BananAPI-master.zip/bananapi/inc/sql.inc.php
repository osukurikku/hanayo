<?php
$sqlcon = new mysqli(
	$sql_settings['ServerName'],
	$sql_settings['User'],
	$sql_settings['Password'],
	$sql_settings['Database']
);
?>