<?php
function getData($in){
	global $sqlcon;
	$out;
	
	$sql = "SELECT * FROM check_table WHERE filename = '".$in."' ORDER BY file_version DESC LIMIT 1;";
	$result = $sqlcon->query($sql);
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$out = $row;
			if($out['url_full'] == null)
				$out['url_full'] = 'http://bananacho.ml/download/dl/'.$in;
			if($out['url_patch'] == null)
				unset($out['url_patch']);
			unset($out['filesize_zip']);
			unset($out['id']);
		}
	}
	return $out;
}

function createDataList(){
	global $sqlcon;
	$out = [];
	
	$sql = "SELECT filename FROM check_table GROUP BY filename;";
	$result = $sqlcon->query($sql);
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$in = getData($row['filename']);
			$out[count($out)] = $in;
		}
	}
	return json_encode(array_values($out));
}
?>