<?php
//Import options variables
include('options.php');

if(in_array('sql', $require))
	include('sql.inc.php');
if(in_array('changelog', $require))
	include('changelog.inc.php');
if(in_array('update', $require))
	include('update.inc.php');
?>