<?php
//SQL
$sql_settings = [
	'ServerName'=> 'localhost',
	'User' 		=> '',
	'Password' 	=> '',
	'Database' 	=> ''
];
?>