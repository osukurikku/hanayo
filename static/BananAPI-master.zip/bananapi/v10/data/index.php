<?php
$require = ['sql'];
include('../../inc/functions.inc.php');
////
////
$s = md5("ripple.moe");
if(isset($_GET['s']))
	$s = $_GET['s'];
////
$out = [];
$sql = "SELECT * FROM data_client WHERE server = '".$s."' ORDER BY id ASC";
$result = $sqlcon->query($sql);
if($result->num_rows > 0)
	while($row = $result->fetch_assoc()){
		unset($row['id']);
		$out[count($out)] = $row;
	}
////
header("Content-Type: application/json");
die(json_encode($out));
?>