<?php
$require = ['sql'];
include('../../inc/functions.inc.php');
////
////
$out = [];
$sql = "SELECT * FROM server_list ORDER BY id ASC";
$result = $sqlcon->query($sql);
if($result->num_rows > 0)
	while($row = $result->fetch_assoc()){
		unset($row['id']);
		$out[count($out)] = $row;
	}
////
header("Content-Type: application/json");
die(json_encode($out));
?>