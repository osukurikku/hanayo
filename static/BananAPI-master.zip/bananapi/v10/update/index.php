<?php
if(!isset($_GET['action']))
	die('No action');

$require = ['sql', 'update'];
include('../../inc/functions.inc.php');
////
////
switch($_GET['action']){
	default:
		echo 'Unknown action...';
		break;
	case "check":
		echo createDataList();
		break;
	case "path":
		echo json_encode(array(getData('osu!.exe')));
		break;
	case "latest":
		echo getData('osu!.exe')['url_full'];
		break;
}
?>