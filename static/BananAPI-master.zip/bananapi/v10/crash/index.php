<?php
$require = ['sql'];
include('../../inc/functions.inc.php');
////
////
$_ = "null";
$v = array_values($_POST);
for($i = 0; $i < count($v); $i++)
	$_ .= ",'".$v[$i]."'";
$sql = "INSERT INTO client_crash VALUES ($_)";
$sqlcon->query($sql);
?>