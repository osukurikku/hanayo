<?php
$require = ['sql','changelog'];
include('../../inc/functions.inc.php');
////
////
$out = rawTxtFormat(clientFormat($changelog));
////
header("Content-type: text/raw");
echo $out;
?>