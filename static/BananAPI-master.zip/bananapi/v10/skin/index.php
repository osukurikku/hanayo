<?php
header('Content-type: application/json');
$servername = "";
$username = "";
$password = "";
$dbname = "";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM skin";
$result = $conn->query($sql);
$myArray = array();

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $myArray[] = $row;
        
    }
} else {
    echo '{"err": null}';
}
$conn->close();
echo json_encode($myArray);